"use strict";
(() => {
  // src/model.ts
  function locate(text, anchor) {
    if (!anchor.exact) return -1;
    const positions = [];
    for (let i = text.indexOf(anchor.exact); i !== -1; i = text.indexOf(anchor.exact, i + 1)) positions.push(i);
    if (positions.length < 2) return positions[0] ?? -1;
    const ranked = positions.map((start) => {
      const before = text.slice(Math.max(0, start - anchor.prefix.length), start);
      const after = text.slice(start + anchor.exact.length, start + anchor.exact.length + anchor.suffix.length);
      let prefix = 0, suffix = 0;
      while (prefix < before.length && before.at(-prefix - 1) === anchor.prefix.at(-prefix - 1)) prefix++;
      while (suffix < after.length && after[suffix] === anchor.suffix[suffix]) suffix++;
      return { start, score: prefix + suffix, distance: Math.abs(start - anchor.start) };
    }).sort((a, b) => b.score - a.score || a.distance - b.distance);
    const [best, runnerUp] = ranked;
    if (best.score === runnerUp.score && (best.score === 0 || best.distance === runnerUp.distance)) return -1;
    return best.start;
  }
  function alignHtmlAnchor(text, anchor) {
    if (!anchor.exact.trim()) return null;
    let start = locate(text, anchor);
    let end = start + anchor.exact.length;
    if (start < 0) {
      const fold2 = (value) => value.replace(/\s+/g, " ");
      const normalized = { ...anchor, exact: fold2(anchor.exact), prefix: fold2(anchor.prefix), suffix: fold2(anchor.suffix) };
      const position = locate(fold2(text), normalized);
      if (position < 0) return null;
      start = position;
      end = position + normalized.exact.length;
      let removed = 0;
      for (const match of text.matchAll(/\s{2,}/g)) {
        const at = match.index - removed;
        if (at >= position + normalized.exact.length) break;
        const extra = match[0].length - 1;
        if (at < position) start += extra;
        end += extra;
        removed += extra;
      }
    }
    return {
      kind: "html",
      start,
      end,
      exact: text.slice(start, end),
      prefix: text.slice(Math.max(0, start - 100), start),
      suffix: text.slice(end, end + 100)
    };
  }

  // src/inline-anchors.ts
  var fold = (text) => text.replace(/\s+/g, " ");
  function inlineQuoteIndex(text) {
    const normalized = fold(text);
    let removed = 0;
    const runs = Array.from(text.matchAll(/\s{2,}/g), (match) => {
      const at = match.index - removed;
      removed += match[0].length - 1;
      return { at, removed };
    });
    function original(offset) {
      let lo = 0, hi = runs.length;
      while (lo < hi) {
        const mid = lo + hi >>> 1;
        if (runs[mid].at < offset) lo = mid + 1;
        else hi = mid;
      }
      return offset + (lo ? runs[lo - 1].removed : 0);
    }
    function positions(exact) {
      const result = [];
      if (!exact.trim()) return result;
      for (let at = normalized.indexOf(exact); at >= 0; at = normalized.indexOf(exact, at + 1)) result.push(at);
      return result;
    }
    return {
      count: (quote) => positions(fold(quote)).length,
      range(anchor) {
        const exact = fold(anchor.exact), prefix = fold(anchor.prefix), suffix = fold(anchor.suffix);
        const matches = positions(exact).map((at) => {
          const end = at + exact.length;
          let left = 0, right = 0;
          while (left < prefix.length && left < at && normalized[at - left - 1] === prefix[prefix.length - left - 1]) left++;
          while (right < suffix.length && normalized[end + right] === suffix[right]) right++;
          return { start: original(at), end: original(end), score: left + right, left, right };
        });
        matches.sort((a, b) => b.score - a.score || Math.abs(a.start - anchor.start) - Math.abs(b.start - anchor.start));
        const [best, second] = matches;
        if (!best) return null;
        if (second?.score === best.score && (!best.score || best.start !== anchor.start)) return null;
        if (anchor.occurrences && matches.length < anchor.occurrences) {
          const stableContext = prefix.length > 0 && best.left >= Math.min(32, prefix.length) || suffix.length > 0 && best.right >= Math.min(32, suffix.length);
          if (!stableContext) return null;
        }
        return { start: best.start, end: best.end };
      }
    };
  }

  // src/html-document.ts
  function collect(root) {
    const doc = root.ownerDocument;
    const scope = doc.defaultView;
    const spans = [];
    const chunks = [];
    let offset = 0;
    let previousBlock = null;
    let lineBreak = false;
    const issues = /* @__PURE__ */ new Set();
    const append = (text2) => {
      chunks.push(text2);
      offset += text2.length;
    };
    function walk(node, block) {
      if (node instanceof scope.Text) {
        if (!node.data.trim() && (!offset || block !== previousBlock || lineBreak)) return;
        if (!node.data.length) return;
        if (offset && (lineBreak || block !== previousBlock)) append("\n");
        const start = offset;
        append(node.data);
        spans.push({ node, start, end: offset });
        previousBlock = block;
        lineBreak = false;
        return;
      }
      if (!(node instanceof scope.Element)) return;
      if (node.matches("script,style,noscript,template,svg,select,textarea,input,button,[hidden]")) return;
      const css2 = scope.getComputedStyle(node);
      if (css2.display === "none" || css2.visibility !== "visible" || css2.contentVisibility === "hidden") return;
      if (node instanceof scope.HTMLBRElement) {
        lineBreak = true;
        return;
      }
      if (node.matches("iframe,frame,object,embed,canvas")) {
        const box = node.getBoundingClientRect();
        if (box.width > 1 && box.height > 1) issues.add("Visible embedded frames or canvas content was omitted.");
        return;
      }
      if (node.shadowRoot) {
        issues.add("Shadow DOM content may be incomplete.");
        for (const child of node.shadowRoot.childNodes) walk(child, node);
        return;
      }
      if (node instanceof scope.HTMLImageElement && node.alt) {
        append(`
[Image: ${node.alt}]
`);
      }
      const nextBlock = /^(block|list-item|table|flex|grid|flow-root)/.test(css2.display) ? node : block;
      for (const child of node.childNodes) walk(child, nextBlock);
    }
    walk(root, null);
    const text = chunks.join("");
    if (!text.trim()) issues.add("No readable document text was found.");
    if (doc.readyState !== "complete") issues.add("The page was still loading.");
    const busySelector = root === doc.body ? 'main [aria-busy="true"], main[aria-busy="true"]' : '[aria-busy="true"]';
    if (root.matches('[aria-busy="true"]') || root.querySelector(busySelector)) {
      issues.add("The document reports that content is still loading.");
    }
    return { text, spans, issues };
  }
  function currentAnchor(text, spans, range) {
    if (!range || range.collapsed || !range.startContainer.isConnected || !range.endContainer.isConnected) return null;
    const selected = spans.filter((span) => range.intersectsNode(span.node));
    if (!selected.length) return null;
    const first = selected[0], last = selected.at(-1);
    const start = first.start + (range.startContainer === first.node ? range.startOffset : 0);
    const end = range.endContainer === last.node ? last.start + range.endOffset : last.end;
    const exact = text.slice(start, end);
    if (!exact.trim() || exact.length > 6e3) return null;
    return { kind: "html", exact, start, end, prefix: text.slice(Math.max(0, start - 100), start), suffix: text.slice(end, end + 100) };
  }
  function htmlThreadRanges(root, threads, mode = "page") {
    const doc = root.ownerDocument;
    const ranges = /* @__PURE__ */ new Map();
    if (!threads.length) return ranges;
    const { text, spans } = collect(root);
    const index = mode === "inline" ? inlineQuoteIndex(text) : null;
    for (const thread of threads) {
      if (thread.anchor.kind !== "html" || !thread.anchor.exact) continue;
      const aligned = index ? index.range(thread.anchor) : mode === "layout" ? alignHtmlAnchor(text, thread.anchor) : null;
      const start = mode === "page" ? locate(text, thread.anchor) : aligned?.start ?? -1;
      const end = aligned?.end ?? start + thread.anchor.exact.length;
      const first = spans.find((span) => span.start <= start && start < span.end);
      const last = spans.find((span) => span.start < end && end <= span.end);
      if (!first || !last || first.node.getRootNode() !== last.node.getRootNode()) continue;
      const range = doc.createRange();
      range.setStart(first.node, start - first.start);
      range.setEnd(last.node, end - last.start);
      ranges.set(thread.id, range);
    }
    return ranges;
  }
  function highlight(root, threads, focus, acrossLayouts = false) {
    const scope = root.ownerDocument.defaultView;
    const ranges = htmlThreadRanges(root, threads, acrossLayouts ? "layout" : "page");
    if (focus) ranges.get(focus)?.startContainer.parentElement?.scrollIntoView({ block: "center", behavior: "smooth" });
    scope.CSS.highlights.set("web-comments", new scope.Highlight(...ranges.values()));
    return threads.filter((thread) => !ranges.has(thread.id)).map((thread) => thread.id);
  }
  function htmlDocument(root, source2) {
    const doc = root.ownerDocument;
    let retained = null;
    function selectedRange() {
      const selection = doc.getSelection();
      if (!selection || !selection.rangeCount) return null;
      const range = selection.getRangeAt(0);
      return root.contains(range.startContainer) && root.contains(range.endContainer) ? range : null;
    }
    function rememberSelection() {
      const range = selectedRange();
      if (range && !range.collapsed) {
        retained = { url: source2().url, range: range.cloneRange() };
      } else if (doc.hasFocus() && (range || root === doc.body)) {
        retained = null;
      }
    }
    doc.addEventListener("selectionchange", rememberSelection);
    return {
      capture(selection) {
        const { text, spans, issues } = collect(root);
        const { url, title } = source2();
        const selected = selectedRange();
        const range = selection ?? (selected && !selected.collapsed ? selected : retained?.url === url ? retained.range : null);
        return {
          url,
          title,
          text,
          kind: "html",
          complete: issues.size === 0,
          note: [...issues].join(" "),
          anchor: currentAnchor(text, spans, range)
        };
      },
      highlight: (threads, focus, acrossLayouts = false) => highlight(root, threads, focus, acrossLayouts),
      dispose: () => doc.removeEventListener("selectionchange", rememberSelection)
    };
  }

  // src/inline-geometry.ts
  function visibleLine(range, last = false) {
    if (!range.startContainer.isConnected) return null;
    let left = 0, top = 0, right = document.documentElement.clientWidth, bottom = window.innerHeight;
    for (let node = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement; node && node !== document.documentElement; node = node.parentElement) {
      const style = getComputedStyle(node);
      if (style.overflowX === "visible" && style.overflowY === "visible") continue;
      const box = node.getBoundingClientRect();
      if (style.overflowX !== "visible") {
        left = Math.max(left, box.left);
        right = Math.min(right, box.right);
      }
      if (style.overflowY !== "visible") {
        top = Math.max(top, box.top);
        bottom = Math.min(bottom, box.bottom);
      }
    }
    const lines = Array.from(range.getClientRects());
    let row = null;
    for (const line of last ? lines.reverse() : lines) {
      const x = Math.max(left, line.left), y = Math.max(top, line.top);
      const width = Math.min(right, line.right) - x, height = Math.min(bottom, line.bottom) - y;
      if (width <= 0 || height <= 0) continue;
      if (!row) row = new DOMRect(x, y, width, height);
      else if (Math.min(row.bottom, y + height) - Math.max(row.top, y) > Math.min(row.height, height) / 2) {
        const rowLeft = Math.min(row.left, x), rowTop = Math.min(row.top, y);
        row = new DOMRect(rowLeft, rowTop, Math.max(row.right, x + width) - rowLeft, Math.max(row.bottom, y + height) - rowTop);
      } else break;
    }
    return row;
  }
  function readingColumn(range) {
    const node = range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentElement;
    return node?.closest("p,li,h1,h2,h3,h4,h5,h6,pre,blockquote,td,th,article,main")?.getBoundingClientRect();
  }
  function cardPosition(range, height) {
    const gap = 8, viewport = document.documentElement.clientWidth;
    let width = Math.min(320, viewport - 2 * gap);
    const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
    height = Math.min(height, Math.max(48, window.innerHeight - 2 * gap));
    let left = viewport - width - gap, top = window.innerHeight - height - 50;
    const anchor = range && visibleLine(range);
    if (anchor) {
      const column = readingColumn(range) ?? anchor;
      const rightSpace = viewport - column.right - 2 * gap, leftSpace = column.left - 2 * gap;
      if (rightSpace >= 240) {
        width = Math.min(width, rightSpace);
        left = column.right + gap;
        top = anchor.top;
      } else if (leftSpace >= 240) {
        width = Math.min(width, leftSpace);
        left = column.left - width - gap;
        top = anchor.top;
      } else {
        left = anchor.left;
        const bottom = visibleLine(range, true)?.bottom ?? anchor.bottom;
        top = bottom + gap + height <= window.innerHeight - gap || bottom + gap <= window.innerHeight - anchor.top ? bottom + gap : anchor.top - height - gap;
      }
    }
    return { left: clamp(left, gap, viewport - width - gap), top: clamp(top, gap, window.innerHeight - height - gap), width, height };
  }

  // src/inline-page.ts
  var highlightName = "web-comments-inline";
  var draftHighlight = "web-comments-inline-draft";
  var css = `
  :host { all:initial; }
  button { position:absolute; pointer-events:auto; box-sizing:border-box; cursor:pointer;
    font:600 13px/1.2 system-ui,sans-serif; color:white; background:#185e56; border:1px solid white;
    border-radius:18px; padding:7px 12px; box-shadow:0 2px 8px #102e3038; white-space:nowrap; }
  button:focus-visible { outline:3px solid #1769c2; outline-offset:2px; }
  .launcher { bottom:10px; right:12px; }
  .marker { width:27px; height:27px; padding:0; border-radius:50% 50% 50% 2px; }
  iframe { position:absolute; pointer-events:auto; box-sizing:border-box; background:white; color-scheme:light;
    border:1px solid #adc4bc; border-radius:12px; box-shadow:0 5px 24px #15372f38; }
  [hidden] { display:none!important; }
`;
  function inlineComments(capture) {
    const host = document.createElement("div");
    host.setAttribute("data-web-comments-overlay", "");
    host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;display:block!important;pointer-events:none!important;z-index:2147483647!important;";
    const shadow = host.attachShadow({ mode: "closed" });
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(css);
    shadow.adoptedStyleSheets = [sheet];
    const abort = new AbortController();
    const { signal } = abort;
    const ticket = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, "0")).join("");
    let port;
    let active = { type: "overview" };
    let pending = { type: "overview" };
    let threads = [], ranges = /* @__PURE__ */ new Map();
    const markers = /* @__PURE__ */ new Map();
    let selected = null, raf = 0, reindex = 0, cardHeight = 180;
    let unavailable = false;
    let returnFocus = null;
    function button(label, cls, click) {
      const node = document.createElement("button");
      node.type = "button";
      node.textContent = label;
      node.className = cls;
      node.addEventListener("click", click);
      shadow.append(node);
      return node;
    }
    const launcher = button("Comments", "launcher", () => {
      if (unavailable) {
        void chrome.runtime.sendMessage({ type: "wc-inline-open-panel" }).catch(() => {
        });
      } else if (active && !frame.hidden) dismiss();
      else show({ type: "overview" });
    });
    launcher.setAttribute("aria-label", "Web Comments");
    const add = button("+ Comment", "add", () => {
      if (!selected) return;
      const snapshot = capture(selected);
      if (snapshot.anchor?.kind === "html") {
        const count = inlineQuoteIndex(snapshot.text).count(snapshot.anchor.exact);
        if (count > 1) snapshot.anchor.occurrences = count;
        active = { type: "draft", range: selected.cloneRange() };
        CSS.highlights.set(draftHighlight, new Highlight(active.range));
        selected = null;
        document.getSelection()?.removeAllRanges();
        present({ type: "draft", capture: snapshot });
      }
    });
    add.setAttribute("aria-label", "Comment on selection");
    add.hidden = true;
    add.addEventListener("mousedown", (event) => event.preventDefault());
    const frame = document.createElement("iframe");
    frame.title = "Web Comments conversation";
    frame.referrerPolicy = "no-referrer";
    frame.src = chrome.runtime.getURL("inline.html") + "#" + ticket;
    shadow.append(frame);
    function present(message) {
      pending = message;
      port?.postMessage(message);
      returnFocus = shadow.activeElement instanceof HTMLButtonElement ? shadow.activeElement : launcher;
      frame.hidden = false;
      frame.focus({ preventScroll: true });
      drawSoon();
    }
    function show(target) {
      selected = null;
      CSS.highlights.delete(draftHighlight);
      active = target;
      present(target);
    }
    function dismiss() {
      CSS.highlights.delete(draftHighlight);
      active = null;
      pending = { type: "overview" };
      frame.hidden = true;
      (returnFocus?.isConnected && !returnFocus.hidden ? returnFocus : launcher).focus({ preventScroll: true });
      drawSoon();
    }
    function selectionChanged() {
      const selection = document.getSelection();
      if (selection?.rangeCount && !selection.isCollapsed) {
        const range = selection.getRangeAt(0);
        const fields = 'input,textarea,[contenteditable]:not([contenteditable="false"]),[role="textbox"]';
        const inField = [range.startContainer, range.endContainer].some((node) => (node instanceof Element ? node : node.parentElement)?.closest(fields));
        const text = range.toString();
        selected = !inField && !document.activeElement?.matches("input,textarea") && document.body.contains(range.commonAncestorContainer) && text.trim() && text.length <= 6e3 ? range.cloneRange() : null;
      } else selected = null;
      drawSoon();
    }
    function place(el, x, y) {
      el.style.left = Math.round(x) + "px";
      el.style.top = Math.round(y) + "px";
    }
    function draw() {
      raf = 0;
      const width = document.documentElement.clientWidth;
      const selection = selected && visibleLine(selected, true);
      add.hidden = unavailable || !selection || active?.type === "draft";
      if (selection && !add.hidden) place(
        add,
        Math.max(4, Math.min(selection.right + 4, width - add.offsetWidth - 4)),
        Math.max(4, Math.min(selection.bottom + 3, innerHeight - add.offsetHeight - 4))
      );
      const visible = [];
      for (const [id, marker] of markers) {
        const range2 = ranges.get(id), box = range2 && visibleLine(range2);
        marker.hidden = !box || active?.type === "thread" && active.id === id;
        if (box && !marker.hidden) visible.push({ id, box });
      }
      const placed = [];
      for (const { id, box } of visible.sort((a, b) => a.box.top - b.box.top)) {
        const marker = markers.get(id);
        const edge = readingColumn(ranges.get(id))?.right ?? box.right;
        const x = Math.max(4, Math.min((edge + 31 <= width ? edge : box.right) + 4, width - 31));
        let y = Math.max(2, box.top);
        for (const other of placed) if (Math.abs(other.x - x) < 29 && Math.abs(other.y - y) < 29) y = other.y + 29;
        if (y + 27 > innerHeight) {
          marker.hidden = true;
          continue;
        }
        place(marker, x, y);
        placed.push({ x, y });
      }
      launcher.setAttribute("aria-expanded", String(!!active && !frame.hidden));
      if (!active || frame.hidden) return;
      const range = active.type === "draft" ? active.range : active.type === "thread" ? ranges.get(active.id) : null;
      const bounds = cardPosition(range ?? null, cardHeight);
      place(frame, bounds.left, bounds.top);
      frame.style.width = bounds.width + "px";
      frame.style.height = bounds.height + "px";
    }
    function drawSoon() {
      if (!raf && !signal.aborted) raf = requestAnimationFrame(draw);
    }
    function indexThreads() {
      reindex = 0;
      ranges = htmlThreadRanges(document.body, threads, "inline");
      const highlights = threads.flatMap((t) => !t.resolved && ranges.has(t.id) ? [ranges.get(t.id)] : []);
      CSS.highlights.set(highlightName, new Highlight(...highlights));
      port?.postMessage({ type: "missing", ids: threads.filter((t) => !ranges.has(t.id)).map((t) => t.id) });
      drawSoon();
    }
    function changed() {
      if (threads.length && !reindex) reindex = window.setTimeout(indexThreads, 120);
      drawSoon();
    }
    function receive(message) {
      switch (message.type) {
        case "threads": {
          threads = message.threads;
          const unresolved = threads.filter((t) => !t.resolved);
          const keep = new Set(unresolved.map((t) => t.id));
          for (const [id, marker] of markers) if (!keep.has(id)) {
            marker.remove();
            markers.delete(id);
          }
          unresolved.forEach((thread, i) => {
            let marker = markers.get(thread.id);
            if (!marker) {
              marker = button("", "marker", () => show({ type: "thread", id: thread.id }));
              markers.set(thread.id, marker);
            }
            marker.textContent = String(i + 1);
            marker.setAttribute("aria-label", "Open comment " + (i + 1));
          });
          launcher.textContent = unresolved.length ? "Comments (" + unresolved.length + ")" : "Comments";
          indexThreads();
          break;
        }
        case "focus": {
          const range = ranges.get(message.id);
          if (range && !visibleLine(range)) range.startContainer.parentElement?.scrollIntoView({ block: "center", inline: "nearest" });
          CSS.highlights.delete(draftHighlight);
          active = { type: "thread", id: message.id };
          drawSoon();
          break;
        }
        case "height":
          cardHeight = Math.max(58, Math.ceil(message.pixels) + 2);
          drawSoon();
          break;
        case "overview":
          CSS.highlights.delete(draftHighlight);
          active = { type: "overview" };
          drawSoon();
          break;
        case "dismiss":
          dismiss();
          break;
      }
    }
    function connected(candidate) {
      if (candidate.name !== "wc-inline:" + ticket || candidate.sender?.id !== chrome.runtime.id) return;
      if (candidate.sender.url && candidate.sender.url.split("#")[0] !== chrome.runtime.getURL("inline.html")) return;
      clearTimeout(fallback);
      if (unavailable) {
        unavailable = false;
        launcher.textContent = "Comments";
        launcher.setAttribute("aria-label", "Web Comments");
        launcher.removeAttribute("title");
        active = { type: "overview" };
        frame.hidden = false;
        drawSoon();
      }
      port = candidate;
      candidate.onMessage.addListener(receive);
      candidate.onDisconnect.addListener(() => {
        if (port === candidate) port = void 0;
      });
      candidate.postMessage({ type: "page", source: location.href });
      candidate.postMessage(pending);
    }
    chrome.runtime.onConnect.addListener(connected);
    document.documentElement.append(host);
    const mutations = new MutationObserver(changed);
    mutations.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["class", "style", "hidden", "open"] });
    const size = new ResizeObserver(drawSoon);
    size.observe(document.documentElement);
    document.addEventListener("selectionchange", selectionChanged, { signal });
    document.addEventListener("scroll", drawSoon, { capture: true, passive: true, signal });
    window.addEventListener("resize", changed, { signal });
    document.addEventListener("load", drawSoon, { capture: true, signal });
    document.fonts.addEventListener("loadingdone", drawSoon, { signal });
    document.addEventListener("click", (event) => {
      if (event.defaultPrevented || event.button !== 0 || !document.getSelection()?.isCollapsed || !(event.target instanceof Element) || event.target.closest("a,button,input,textarea,select,[contenteditable]") || event.target === host) return;
      const caret = document.caretRangeFromPoint(event.clientX, event.clientY);
      if (!caret) return;
      for (const [id, range] of ranges) if (markers.has(id) && range.isPointInRange(caret.startContainer, caret.startOffset) && Array.from(range.getClientRects()).some((r) => event.clientX >= r.left && event.clientX < r.right && event.clientY >= r.top && event.clientY < r.bottom)) {
        show({ type: "thread", id });
        break;
      }
    }, { signal });
    const fallback = window.setTimeout(() => {
      if (port) return;
      unavailable = true;
      frame.hidden = true;
      active = null;
      add.hidden = true;
      launcher.textContent = "Use Chrome side panel";
      launcher.setAttribute("aria-label", "Open Web Comments in the Chrome side panel");
      launcher.title = "The comment card could not load on this page";
      drawSoon();
    }, 6500);
    selectionChanged();
    drawSoon();
    return () => {
      abort.abort();
      clearTimeout(fallback);
      clearTimeout(reindex);
      cancelAnimationFrame(raf);
      mutations.disconnect();
      size.disconnect();
      chrome.runtime.onConnect.removeListener(connected);
      port?.disconnect();
      CSS.highlights.delete(highlightName);
      CSS.highlights.delete(draftHighlight);
      host.remove();
    };
  }

  // src/extension-auth.ts
  var extensionSignInPath = "/extension/sign-in";
  var browserAuthMessage = "wc-browser-auth";
  var browserAuthResult = "wc-browser-auth-result";
  var challengePattern = /^[0-9a-f]{32}$/;
  function authTokens(value) {
    if (!value || typeof value !== "object" || !("access_token" in value) || !("refresh_token" in value)) return null;
    const { access_token, refresh_token } = value;
    if (typeof access_token !== "string" || typeof refresh_token !== "string" || !access_token || !refresh_token || access_token.length > 16384 || refresh_token.length > 2048) return null;
    return { access_token, refresh_token };
  }

  // src/content.ts
  var source = () => ({ url: location.href, title: document.title || location.hostname });
  var body = document.body;
  var page = htmlDocument(body, source);
  function currentPage() {
    if (body !== document.body) {
      page.dispose();
      body = document.body;
      page = htmlDocument(body, source);
    }
    return page;
  }
  var inline;
  function setInline(active) {
    if (active && !inline && document.contentType === "text/html" && location.pathname !== extensionSignInPath) {
      inline = inlineComments((range) => currentPage().capture(range));
    } else if (!active && inline) {
      inline();
      inline = void 0;
    }
  }
  var activationChanged = false;
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message.type === "wc-html-capture") respond(currentPage().capture());
    if (message.type === "wc-html-highlights") respond(currentPage().highlight(message.threads, message.focus));
    if (message.type === "wc-inline-active") {
      activationChanged = true;
      setInline(message.active === true);
      respond(true);
    }
  });
  void chrome.runtime.sendMessage({ type: "wc-inline-restore" }).then((active) => {
    if (!activationChanged && active === true) setInline(true);
  }).catch(() => {
  });
  var currentUrl = location.href;
  function navigated() {
    if (currentUrl === location.href) return;
    currentUrl = location.href;
    if (inline) {
      setInline(false);
      setInline(true);
    }
  }
  var navigation = window.navigation;
  navigation?.addEventListener("currententrychange", navigated);
  window.addEventListener("pageshow", navigated);
  if (window === window.top && location.pathname === extensionSignInPath) {
    window.addEventListener("message", (event) => {
      const { data } = event;
      if (event.source !== window || event.origin !== location.origin || data?.type !== browserAuthMessage || typeof data.state !== "string" || !challengePattern.test(data.state)) return;
      const tokens = authTokens(data.tokens);
      if (!tokens) return;
      void chrome.runtime.sendMessage({ type: browserAuthMessage, state: data.state, tokens }).then((answer) => answer?.ok === true, () => false).then((ok) => window.postMessage({ type: browserAuthResult, state: data.state, ok }, location.origin));
    });
  }
})();
